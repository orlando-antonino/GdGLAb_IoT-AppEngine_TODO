<?php

	// http://localhost/tps/indgdg.php?text=testo
	// Set a test api key !!!

	$apiKey = "";
	echo 'API key from Google developer API console'. $apiKey.'<br /> <br />';

	//These are the keys this script will notify. 

	$registrationIDs = array();

	$account = array ("nex"=>"");

	$myFile = "fold/testFile.txt";
	$fh = fopen($myFile, 'r');
	$theData = fread($fh, filesize($myFile));
	fclose($fh);
	echo 'registration id from file: '.$theData. '<br /> <br />';


	$account["nex"] = $theData;
	//print_r($account["nex"].'<br /> <br />');


	$e=0;
	foreach ($account as $i => $value){
		$registrationIDs[$e]=$value;
		$e++;
	}

	// $msg is the message that will be sent.  Let me know the properties I am to expect. 
	$msg = array();

	if( isset($_GET['ttext']) )$msg['ttext'] = $_GET['ttext'];
	if( isset($_GET['title']) )$msg['title'] = $_GET['title'];
	if( isset($_GET['text']) )$msg['text'] = $_GET['text'];
	if( isset($_GET['img']) )$msg['img'] = $_GET['img'];
	if( isset($_GET['img_url']) )$msg['img_url'] = $_GET['img_url'];
	if( isset($_GET['url']) )$msg['url'] = $_GET['url'];
	if( isset($_GET['snd']) )$msg['snd'] = $_GET['snd'];
	if( isset($_GET['ico']) )$msg['ico'] = $_GET['ico'];
	if( isset($_GET['tag']) )$msg['tag'] = $_GET['tag'];
	if( isset($_GET['type']) )$msg['type'] = $_GET['type'];


	$msg = json_encode($msg);
	// Set POST variables
	echo 'JSON to send: '.$msg.'<br /> <br />';
	$url = 'https://android.googleapis.com/gcm/send';

	$fields = array(
		        'registration_ids'  => $registrationIDs,
		        'data'              => array( "message" => $msg ),
		        );

	$headers = array( 
		            'Authorization: key=' . $apiKey,
		            'Content-Type: application/json'
		        );

	// Open connection
	$ch = curl_init();

	// Set the url, number of POST vars, POST data
	curl_setopt( $ch, CURLOPT_URL, $url );

	curl_setopt( $ch, CURLOPT_POST, true );
	curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );

	curl_setopt( $ch, CURLOPT_POSTFIELDS, json_encode( $fields ) );

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

	// Execute post
	  $result = curl_exec($ch);
	   if(curl_errno($ch) !== 0) {
	       echo "<pre>";
		print_r(curl_errno($ch));
		print_r(curl_error($ch));
	       echo "</pre>";
	   }

	// Close connection
	curl_close($ch);

	echo 'response from GCM server'.$result;
?>
